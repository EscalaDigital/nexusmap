<div id="mapabase" class="nm-form-field" data-type="map">
            <label>Mapa</label>
            <div id="nm-map-canvas"></div>
            <div class="nm-field-restricted"><label style="font-size:11px;display:inline-block;margin-top:4px;"><input type="checkbox" class="field-restricted-toggle" <?php echo !empty($field['restricted']) ? 'checked' : ''; ?>> Solo usuarios privilegiados</label></div>
        </div>